#include <stdio.h>
#include "structure.h"

int main(void) {
  structure();
  return 0;
}