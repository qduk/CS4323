#ifndef STRUCTURE_H
#define STRUCTURE_H

int structure();

struct User{
  char employeeName[50];
  char jobTitle[50];
  char status[50];
};

#endif
